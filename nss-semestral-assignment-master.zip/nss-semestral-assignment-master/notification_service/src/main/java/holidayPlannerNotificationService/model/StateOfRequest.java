package holidayPlannerNotificationService.model;

public enum StateOfRequest {
    IN_PROGRESS, ACCEPTED, DECLINED
}
