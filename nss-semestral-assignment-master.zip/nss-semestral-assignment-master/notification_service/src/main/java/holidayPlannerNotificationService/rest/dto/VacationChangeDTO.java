package holidayPlannerNotificationService.rest.dto;

public class VacationChangeDTO {
    private String changes;

    public String getChanges() {
        return changes;
    }

    public void setChanges(String changes) {
        this.changes = changes;
    }
}
