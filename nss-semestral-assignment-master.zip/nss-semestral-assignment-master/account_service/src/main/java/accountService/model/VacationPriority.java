package accountService.model;

public enum VacationPriority {
    HIGH, MEDIUM, LOW
}
