package accountService.model;


public enum VacationReason {
    HOSPITAL,
    FAMILY,
    HOLIDAY,
}
