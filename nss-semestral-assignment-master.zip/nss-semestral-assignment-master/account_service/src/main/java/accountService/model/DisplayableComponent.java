package accountService.model;

public interface DisplayableComponent {

}
