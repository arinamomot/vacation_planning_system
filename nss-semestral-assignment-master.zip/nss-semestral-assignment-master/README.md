_**README**_

_Popis a struktura aplikace:_

Aplikace je napsána za pomoci frameworku Spring-Boot.
Jedná se o aplikaci microservice patternu, přičemž aplikace je dělena na AccountService a NotificationService.
Připojuje se k PostgreSQL databázi, která obsahuje všechny podstatné entity, se kterými aplikace pracuje (tj. User, Team, Group, VacationDay,.. ).
Aplikace využívá JPA k práci s databázovými entitami.
Nad vrstou modelu je postavena DAO vrstva, která zapouzdřuje CRUD operace s entitami.
DAO objekty dědí z obecného GenericDao, některé přidávají své speciální metody.
Nad DAO vrstvou pracuje vrstva servisní, která je jakýmsi adaptérem business operací na DAO operace.
Tato vrstva již tedy obsahuje business logiku, v našem případě například řeší, zdali si uživatel smí vybrat dovolenou v daný den či nikoli.
Na nejvyšší vrstvě jsou restové endpointy, které lze volat z webového prostředí.
Endpointy řeší kupříkladu registraci uživatele, vytvoření týmu nebo pracovní skupiny, přidání člena do skupiny apod.
REST rozhraní je z bezpečnostních důvodů obaleno security vstrvou, kde pomocí anotací (převážně @PreAuthorized) definujeme, 
kteří uživatelé smí na daný endpoint přistupovat.
Nastavuje se zde např. uživatelská session, ze třídy SecurityUtils lze získat aktuálního uživatele, provádí se zde
autentikace a autorizace.

V našem systému existují 4 uživatelské role.
 - Guest - anonymní uživatel
 - User - běžný uživatel systému 
 - Admin - běžný uživatel systému, který je však správcem 1 týmu
 - Main admin - správce celého systému

Aplikace mimo to obsahuje balíček _config_, který řeší konfuguraci persistence a security.

# Architektura
## Account Service
Account Service má na starost:
- data uživatelů systému
- týmy a skupiny
- dovolené

Technologie: **SpringBoot, PostgreSQL**

Package: **cz.cvut.fel.nss.holidayPlanner.AccountService**

## Notification Service
Má na starost notifikace, konkrétně:
- žádost o přidání do týmu -> poslání notifikace adminovi
- schválení/zamítnutí žádosti
- notifikace žádajícího
- notifikace o změně dovolené
  - drží si identifikátory z account servisu pro propojení dat na frontendu
  Technologie: SpringBoot, PostgreSQL

Technologie: **SpringBoot, PostgreSQL**

Package: **cz.cvut.fel.nss.holidayPlanner.NotificationService**
  
## Front-end 
- volá přímo account i notification service
- přihlašuje se do obou servis zároveň přes stejné credentials -> 2x cookie (JSESSION)

**FE podporuje následující Uce Casy**:
- registrace/login/logout
- vytvoření týmu
- vytvoření skupiny
- vstup do skupiny
- opustit skupiny
- zobrazit týmu
- žádost o vstup do týmu přes notifikaci
- schválit/zamítnout žádost adminem 
- notifikovat žádajícího o výsledku
- zobrazit kalendář dovolené celého týmu
- přidat dovolenou

Technologie: **React**

Adresář: /frontend

## Design patterny
- **Facade** [(account_service/src/main/java/accountService/facade/GroupFacade.java)](account_service/src/main/java/accountService/facade/GroupFacade.java)
- **Interceptors** [(account_service/src/main/java/accountService/interceptor/AccountServiceInterceptor.java)](account_service/src/main/java/accountService/interceptor/AccountServiceInterceptor.java)
- **DTO** [(account_service/src/main/java/accountService/rest/dto/GroupDTO.java)](account_service/src/main/java/accountService/rest/dto/GroupDTO.java)
- **DAO** [(notification_service/target/classes/holidayPlannerNotificationService/dao/BaseDao.class)](notification_service/target/classes/holidayPlannerNotificationService/dao/BaseDao.class)
- **Cache** [(account_service/src/main/java/accountService/config/RedisConfig.java)](account_service/src/main/java/accountService/config/RedisConfig.java)
- **Factory Method** [(account_service/src/main/java/accountService/config/RedisConfig.java)](account_service/src/main/java/accountService/config/RedisConfig.java)
- **Dependency injection** (@Autowire, @Inject)

